import matplotlib.pyplot as plt
from sklearn.utils import shuffle
from keras import callbacks
import os,time
from keras.models import Model
import numpy as np
import nibabel as nib
from functools import partial
import os
import numpy as np
from keras.models import Model 
from keras.layers import Input, concatenate, Conv2D, MaxPooling2D, Conv2DTranspose,Dropout,BatchNormalization
from keras.optimizers import Adam
from keras import callbacks
from keras import backend as K
from keras.utils import plot_model
import h5py
from keras import optimizers
from model import Nestnet
import time
BASE=64
num_classes=5
patch_size=384




os.environ["CUDA_VISIBLE_DEVICES"] = "1"
#dice
def computeDice(img_true,img_pre):
    intersection = np.sum(img_true * img_pre)
    dsc= (2. * intersection+1) / (np.sum(img_true) + np.sum(img_pre)+1)
    return dsc


model=Nestnet()
model.load_weights("/data/ydeng1/OAI/Unet++/outputs/TC_weights2.h5")
output='/data/ydeng1/OAI/Unet_2D/results3/'

test_img=sorted(os.listdir("/data/ydeng1/OAI/slice_data/test_data/image/"))
test_gt=sorted(os.listdir("/data/ydeng1/OAI/slice_data/test_data/label/"))

DSC_FB=[]
DSC_FC=[]
DSC_TB=[]
DSC_TC=[]

# separate labels
def separate_labels(patch_2d_volume):
    result =np.empty(shape=[0,patch_size,patch_size,num_classes], dtype='int16')
    patch_3d_volume=np.expand_dims(patch_2d_volume, axis=0)
    N = patch_3d_volume.shape[0]
    # for each class do:
    for V in range(N):
        V_patch = patch_3d_volume[V , :, :]
        U  = np.unique(V_patch)
        unique_values = list(U)
        result_v =np.empty(shape=[patch_size,patch_size,0], dtype='int16')

        for label in range(0,num_classes):
            if label in unique_values:
                im_patch = V_patch == label
                im_patch = im_patch*1
            else:
                im_patch = np.zeros((V_patch.shape))
             
            im_patch = np.expand_dims(im_patch, axis=2) 
            result_v  = np.append(result_v,im_patch, axis=2)
        result_v = np.expand_dims(result_v, axis=0) 
        result  = np.append(result,result_v, axis=0)
    return result

time1=time.time()
for X,Y in zip(test_img,test_gt):
    X_test=np.load(os.path.join("/data/ydeng1/OAI/slice_data/test_data/image/",X))
    X_test=(X_test-np.min(X_test))/(np.max(X_test)-np.min(X_test))
    X_test=np.expand_dims(X_test,axis=0)
    X_test=np.expand_dims(X_test,axis=3)
    X_test=np.repeat(X_test,3,axis=3)
    Y_test=np.load(os.path.join('/data/ydeng1/OAI/slice_data/test_data/label/',Y))
    #print(Y_test.shape,'888888888')
    #Y_test=separate_labels(label)
    
    
    y_pred = model.predict(X_test)
    #print(y_pred.shape,'tttttttttttt')
    '''
    plt.subplot(1,4,1)
    plt.imshow(y_pred[0,:,:,0],'gray')
    plt.subplot(1,4,2)
    plt.imshow(X_test[0,:,:,0],'gray')
    plt.subplot(1,4,3)
    plt.imshow(Y_test,'gray')
    y_pred[y_pred>=0.4]=1
    y_predi=np.squeeze(y_pred)
    plt.subplot(1,4,4)
    plt.imshow(y_predi,'gray')
    plt.show()    
    '''
    y_pred[y_pred>=0.8]=1
    y_pred[y_pred<0.8]=0
    y_predi=np.squeeze(y_pred)    
    #print(y_predi.shape,Y_test.shape,'iiiiiiiiiiiiiii')
    TC=(y_predi==1)*1
    TC_gt=(Y_test==4)*1  
   
    dice_TC=computeDice(TC,TC_gt)
    DSC_TC.append(dice_TC)
    a=dice_TC
    f = open("TC_result.txt", 'a')
    f.write(str(a))
    f.write("\n")
    
time2=time.time()    
print('mean dice of TC is:',np.mean(DSC_TC))
print('max dice of TC is:',np.max(DSC_TC))
print('min dice of TC is:',np.min(DSC_TC)) 
print('time is:',time2-time1)


